import { Component, OnInit } from '@angular/core';
import { Recipe } from '../food';
import { FoodServiceService } from '../food-service.service';

@Component({
  selector: 'app-home-list',
  templateUrl: './home-list.component.html',
  styleUrls: ['./home-list.component.css'],
  providers: [FoodServiceService]
})

export class HomeListComponent implements OnInit {

  recipes: Recipe[]

  constructor(private foodService: FoodServiceService) { }

  ngOnInit() {
     this.foodService
      .getFoods()
      .then((recipes: Recipe[]) => {
        this.recipes = recipes.map(food => {
          return food;
        });
      });
      }
  onDeleteRecipe(id){
     this.foodService.deleteRecipe(id) 
        .then((recipe: Recipe) => {
         this.foodService
        .getFoods()
        .then((recipes: Recipe[]) => {
        this.recipes = recipes.map(food => {
        return food;
            });
        });
        console.log(Recipe);
      })
      
  }
}