import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FoodServiceService } from '../food-service.service';
import { Recipe } from '../food';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css'],
  providers: [FoodServiceService]
})
export class UpdateComponent implements OnInit {

  
  
  constructor(
    private foodServiceService: FoodServiceService,
    private route: ActivatedRoute
    ) { }
    newRecipe: Recipe;

    ngOnInit(): void {
      this.route.params.pipe(
        switchMap((params: Params) => {
        return this.foodServiceService.getSingleFood(params['recipeid'])
    })
    )
    .subscribe((newRecipe: Recipe) => {
        this.newRecipe = newRecipe;
        this.pageContent.header.title = newRecipe.name;
        this.pageContent.header.body = "Details for selected recipe";
    });
  }
  pageContent = {
        header : {
            title : '',
            body : ''
        }
  };
  
  public updateNewRecipe(id: string): void{
    this.foodServiceService.updateRecipe(id, this.newRecipe);
  }

}
