export class Recipe {
        _id?: string;
        name: string;
        type: string;
        availability: boolean;
}
