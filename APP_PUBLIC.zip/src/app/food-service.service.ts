import { Injectable } from '@angular/core';
import { Recipe } from './food';
import { Http, Response } from '@angular/http';

@Injectable()
export class FoodServiceService {

  private recipesUrl = 'http://localhost:3000/api/recipes';
  
  constructor(private http: Http) {}
    // get("/api/recipes")
    getFoods(): Promise<void | Recipe[]> {
      return this.http.get(this.recipesUrl)
                 .toPromise()
                 .then(response => response.json() as Recipe[])
                 .catch(this.handleError);
    }
    getSingleFood(recipeid: String) : Promise<void | Recipe>{
        return this.http.get(this.recipesUrl + '/' + recipeid)
                    .toPromise()
                    .then(response => response.json() as Recipe)
                    .catch(this.handleError);
    }
    
    createRecipe(newRecipe: Recipe): Promise<void | Recipe> {
        return this.http.post(this.recipesUrl, newRecipe)
                    .toPromise()
                    .then(response => response.json() as Recipe)
                    .catch(this.handleError);
    }
    
    updateRecipe(recipeid: String, newRecipe: Recipe): Promise<void | Recipe> {
        return this.http.put(this.recipesUrl + '/' + recipeid, newRecipe)
                    .toPromise()
                    .then(response => response.json() as Recipe)
                    .catch(this.handleError);
    }
    
    deleteRecipe(recipeid)
    {
        return this.http.delete(this.recipesUrl + '/' + recipeid)
                .toPromise()
                 .then(response => response.json() as Recipe)
                .catch(this.handleError);
    }

    
    private handleError (error: any) {
      console.log("error");
    }
}
