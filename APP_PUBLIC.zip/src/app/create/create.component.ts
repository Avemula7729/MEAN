import { Component, OnInit, Input } from '@angular/core';
import { Recipe } from '../food';
import { FoodServiceService } from '../food-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
  providers: [FoodServiceService]
})
export class CreateComponent implements OnInit {
    public newRecipe: Recipe = {
        _id: '',
        name: '',
        type: '',
        availability: true
    };

  constructor( private foodServiceService: FoodServiceService) { }

  ngOnInit() {
  }
  public createNewRecipe(newRecipe: Recipe): void{
    this.foodServiceService.createRecipe(newRecipe);
  }
}
