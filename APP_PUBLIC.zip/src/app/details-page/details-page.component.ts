import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FoodServiceService } from '../food-service.service';
import { Recipe } from '../food';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-details-page',
  templateUrl: './details-page.component.html',
  styleUrls: ['./details-page.component.css'],
  providers: [FoodServiceService]
})
export class DetailsPageComponent implements OnInit {

  constructor(
    private foodServiceService: FoodServiceService,
    private route: ActivatedRoute
    ) { }
    newRecipe: Recipe;

    ngOnInit(): void {
    this.route.params.pipe(
    switchMap((params: Params) => {
    return this.foodServiceService.getSingleFood(params['recipeid'])
    })
    )
    .subscribe((newRecipe: Recipe) => {
        this.newRecipe = newRecipe;
        this.pageContent.header.title = newRecipe.name;
        this.pageContent.header.body = "Details for selected recipe";
    });
  }
  pageContent = {
        header : {
            title : '',
            body : ''
        }
  };
}
